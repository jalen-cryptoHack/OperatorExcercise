import UIKit

// Varibles
var Number1 = 10
var Number2 = 20
var Number3 = 30
var Number4 = 40
var Number5 = 50
var Number6 = 60

// Operators
2 + 2
2 - 2
2 * 2
2/2

// results
print (Number3 + Number2)
print(Number4 - Number5)
print(Number3 * Number6)
print (Number6/Number2)
